# frozen_string_literal: true

Gem::Specification.new do |spec|
  spec.name = "ubi-csi"
  spec.version = "0.10.0"
  spec.authors = ["Ubicloud"]
  spec.email = ["support@ubicloud.com"]

  spec.summary = "Ubicloud CSI Driver"
  spec.description = "Container Storage Interface driver for Ubicloud"
  spec.homepage = "https://github.com/ubicloud/ubicloud"
  spec.license = "MIT"
  spec.required_ruby_version = "~> 4.0"

  spec.files = Dir["lib/**/*", "bin/**/*"]
  spec.bindir = "bin"
  spec.executables = ["ubi-csi-server"]
  spec.require_paths = ["lib"]

  spec.add_dependency "base64"
  spec.add_dependency "logger"
  spec.add_dependency "grpc", "1.78.1"
  spec.add_dependency "grpc-tools", "1.78.1"

  spec.add_development_dependency "rspec", "~> 3.12"
  spec.add_development_dependency "simplecov", "~> 0.22"
  spec.add_development_dependency "simplecov-console", "~> 0.9"
end
