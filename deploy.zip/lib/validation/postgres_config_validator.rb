# frozen_string_literal: true

module Validation
  class PostgresConfigValidator
    # Custom option keys have two parts separated by a dot:
    # https://www.postgresql.org/docs/18/runtime-config-custom.html
    #
    # Each part must start with a letter or underscore followed by letters,
    # digits, or underscores.
    # https://github.com/postgres/postgres/blob/0392fb900eb89f52988cccd33046443c39c70d1c/src/backend/utils/misc/guc.c#L957
    #
    # Notes:
    # - Postgres implementation allows >= 2 parts, but docs only mention 2
    #   parts, so we enforce 2 parts per the docs.
    # - Postgres allows dollars and high-bit characters in option names, but the
    #   PgCommon.pm preloader rejects them before passing them to postgres, so
    #   disallow them here.
    EXTENSION_KEY_REGEX = /\A[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*\z/

    def initialize(version)
      case version
      when "17"
        @config_schema = Validation::PostgresConfigValidatorSchema::PG_17_CONFIG_SCHEMA
      when "16"
        @config_schema = Validation::PostgresConfigValidatorSchema::PG_16_CONFIG_SCHEMA
      when "18"
        @config_schema = Validation::PostgresConfigValidatorSchema::PG_18_CONFIG_SCHEMA
      when "pgbouncer"
        @config_schema = Validation::PostgresConfigValidatorSchema::PGBOUNCER_CONFIG_SCHEMA
      else
        raise "Unsupported version: #{version}"
      end
    end

    def restart_required_params
      @restart_required_params ||= @config_schema.select { |_, v| v[:requires_restart] }.keys.to_set.freeze
    end

    def requires_restart?(key)
      restart_required_params.include?(key)
    end

    def validate(config)
      errors = validation_errors(config)

      if errors.any?
        raise Validation::ValidationFailed.new(errors)
      end
    end

    def validation_errors(config)
      errors = {}
      config.each do |key, value|
        str = value.to_s
        errors[key] = if str.empty?
          "Value cannot be empty"
        elsif str.include?("\n")
          "Value cannot contain newlines"
        elsif valid_config?(key)
          validate_config(key, value)
        elsif EXTENSION_KEY_REGEX.match?(key)
          nil
        else
          "Unknown configuration parameter"
        end
      end
      errors.compact!
      errors
    end

    private

    def valid_config?(key)
      @config_schema.key?(key)
    end

    def validate_config(key, value)
      config = @config_schema[key]

      if config[:deny]
        return ["Modifying this parameter is not allowed"]
      end

      errors = []

      begin
        value = Integer(value) if config[:type] == :integer
      rescue
        errors << "must be an integer"
      end

      begin
        value = Float(value) if config[:type] == :float
      rescue
        errors << "must be a float"
      end

      # Validate type
      case config[:type]
      when :integer
        errors << validate_integer_range(value, config[:min], config[:max]) if value.is_a?(Integer)
      when :float
        errors << validate_float_range(value, config[:min], config[:max]) if value.is_a?(Float)
      when :enum
        errors << validate_enum(value, config[:allowed_values])
      when :string
        errors << validate_string(value, config[:pattern])
      when :bool
        errors << validate_bool(value)
      else
        errors << "Unknown type #{config[:type]}"
      end

      errors.compact!
      errors.any? ? errors : nil
    end

    def validate_integer_range(value, min, max)
      return nil if value.between?(min, max)

      "must be between #{min} and #{max}"
    end

    def validate_float_range(value, min, max)
      return nil if value.between?(min, max)

      "must be between #{min} and #{max}"
    end

    def validate_enum(value, allowed_values)
      return nil if allowed_values.include?(value)

      "must be one of: #{allowed_values.join(", ")}"
    end

    def validate_string(value, pattern)
      # Check pattern validation first if pattern is specified
      if pattern && !pattern.match?(value)
        return "must match pattern: #{pattern.source.gsub(/[\\Az]/, "")}"
      end

      # Values are auto-quoted when written to postgresql.conf, so users
      # should not wrap them in single quotes. Reject quoted values.
      starts = value.start_with?("'")
      ends = value.end_with?("'")
      if starts && ends && value.length >= 2
        "must not be wrapped in single quotes - quoting is handled automatically"
      elsif starts != ends
        "has a mismatched single quote"
      end
    end

    def validate_bool(value)
      return nil if ["on", "of", "off", "t", "tr", "tru", "true", "f", "fa", "fal", "fals", "false", "1", "0"].include?(value.downcase)

      "must be 'on' or 'off' or 'true' or 'false' or '1' or '0' or any unambiguous prefix of these values (case-insensitive)"
    end
  end
end
