# frozen_string_literal: true

require "yaml"

module Option
  ai_models = YAML.load_file("config/ai_models.yml")
  AI_MODELS = ai_models.select { it["enabled"] }.freeze

  def self.locations(only_visible: true, feature_flags: {})
    locs = Location.where(project_id: nil).all.select { |pl| !only_visible || (pl.visible || feature_flags["visible_locations"]&.include?(pl.name)) }
    if Config.compute_provider
      locs.select! { |it| it.provider == Config.compute_provider }
    end
    locs
  end

  def self.kubernetes_locations
    if Config.compute_provider
      Location.where(provider: Config.compute_provider, project_id: nil, visible: true).all
    else
      Location.where(name: ["hetzner-fsn1", "leaseweb-wdc02"]).all
    end
  end

  def self.kubernetes_versions
    ["v1.36", "v1.35", "v1.34", "v1.33"].freeze
  end

  def self.selectable_kubernetes_versions
    kubernetes_versions.first(2)
  end

  LinodePlan = Data.define(:id, :label, :family, :size_name, :vcpus, :memory_gib, :disk_gib, :monthly_price, :hourly_price, :gpu_count, :gpu_device, :billing_family)
  LINODE_MARKUP = 1.30
  AZURE_MARKUP = 1.00
  LINODE_GPU_DEVICE = "27b0"
  LINODE_LOCATIONS = [
    ["linode-de-fra-2", "de-fra-2", "Frankfurt, DE"],
    ["linode-us-east", "us-east", "Newark, NJ"],
    ["linode-us-lax", "us-lax", "Los Angeles, CA"],
    ["linode-us-sea", "us-sea", "Seattle, WA"],
  ].map(&:freeze).freeze
  LINODE_GPU_LOCATION_NAMES = ["linode-de-fra-2", "linode-us-sea"].freeze
  LINODE_PLANS = [
    LinodePlan.new("g6-nanode-1", "Nanode 1GB", "nanode", "nanode-1", 1, 1, 25, 5, 0.0075, 0, nil, "nanode"),
    LinodePlan.new("g6-standard-1", "Starter 2GB", "nanode", "nanode-2", 1, 2, 50, 12, 0.018, 0, nil, "nanode-2"),
    LinodePlan.new("g6-standard-2", "Starter 4GB", "nanode", "nanode-4", 2, 4, 80, 24, 0.036, 0, nil, "nanode-4"),
    LinodePlan.new("g6-standard-4", "Starter 8GB", "nanode", "nanode-8", 4, 8, 160, 48, 0.072, 0, nil, "nanode-8"),
    LinodePlan.new("g6-standard-1", "Shared 2GB", "burstable", "burstable-1", 1, 2, 50, 12, 0.018, 0, nil, "burstable"),
    LinodePlan.new("g6-standard-2", "Shared 4GB", "burstable", "burstable-2", 2, 4, 80, 24, 0.036, 0, nil, "burstable"),
    LinodePlan.new("g7-dedicated-4-2", "Dedicated 4GB", "standard", "standard-2", 2, 4, 80, 43, 0.0645, 0, nil, "standard"),
    LinodePlan.new("g7-dedicated-8-4", "Dedicated 8GB", "standard", "standard-4", 4, 8, 160, 86, 0.129, 0, nil, "standard"),
    LinodePlan.new("g7-dedicated-16-8", "Dedicated 16GB", "standard", "standard-8", 8, 16, 320, 173, 0.2595, 0, nil, "standard"),
    LinodePlan.new("g7-dedicated-32-16", "Dedicated 32GB", "standard", "standard-16", 16, 32, 640, 346, 0.519, 0, nil, "standard"),
    LinodePlan.new("g2-gpu-rtx4000a1-s", "RTX 4000 Ada x1 Small", "standard", "standard-4", 4, 16, 512, 350, 0.52, 1, LINODE_GPU_DEVICE, "standard"),
  ].freeze
  LINODE_BOOT_IMAGES = {
    "ubuntu-noble" => "linode/ubuntu24.04",
    "ubuntu-jammy" => "linode/ubuntu22.04",
    "gpu-ubuntu-noble" => "linode/ubuntu24.04",
    "debian-12" => "linode/debian12",
    "almalinux-9" => "linode/almalinux9",
    "rocky-9" => "linode/rocky9",
  }.freeze

  AzurePlan = Data.define(:id, :label, :family, :size_name, :vcpus, :memory_gib, :disk_gib, :monthly_price, :hourly_price, :gpu_count, :gpu_device, :billing_family)
  AZURE_LOCATIONS = [
    ["azure-eastus", "eastus", "East US"],
    ["azure-eastus2", "eastus2", "East US 2"],
    ["azure-centralus", "centralus", "Central US"],
    ["azure-westeurope", "westeurope", "West Europe"],
    ["azure-northeurope", "northeurope", "North Europe"],
  ].map(&:freeze).freeze
  AZURE_PLANS = [
    AzurePlan.new("Standard_D2lds_v7", "Starter 4GB", "nanode", "nanode-4", 2, 4, 80, 10, 0.015, 0, nil, "nanode-4"),
    AzurePlan.new("Standard_D4lds_v7", "Starter 8GB", "nanode", "nanode-8", 4, 8, 160, 20, 0.030, 0, nil, "nanode-8"),
    AzurePlan.new("Standard_D2ds_v7", "Shared 8GB", "burstable", "burstable-2", 2, 8, 80, 10, 0.015, 0, nil, "burstable-2"),
    AzurePlan.new("Standard_D4ds_v7", "Shared 16GB", "burstable", "burstable-4", 4, 16, 160, 20, 0.030, 0, nil, "burstable-4"),
    AzurePlan.new("Standard_D8ds_v7", "Shared 32GB", "burstable", "burstable-8", 8, 32, 320, 50, 0.075, 0, nil, "burstable-8"),
    AzurePlan.new("Standard_D2ds_v7", "Dedicated 8GB", "standard", "standard-2", 2, 8, 80, 20, 0.030, 0, nil, "standard-2"),
    AzurePlan.new("Standard_D4ds_v7", "Dedicated 16GB", "standard", "standard-4", 4, 16, 160, 50, 0.075, 0, nil, "standard-4"),
    AzurePlan.new("Standard_D8ds_v7", "Dedicated 32GB", "standard", "standard-8", 8, 32, 320, 95, 0.1425, 0, nil, "standard-8"),
    AzurePlan.new("Standard_D16ds_v7", "Dedicated 64GB", "standard", "standard-16", 16, 64, 640, 180, 0.270, 0, nil, "standard-16"),
    AzurePlan.new("Standard_D32ds_v7", "Dedicated 128GB", "standard", "standard-30", 30, 128, 1280, 350, 0.525, 0, nil, "standard-30"),
  ].freeze
  AZURE_LOCATION_PLAN_IDS = {
    "azure-westeurope" => {
      "nanode-4" => "Standard_D2lds_v6",
      "nanode-8" => "Standard_D4lds_v6",
      "burstable-2" => "Standard_D2ds_v6",
      "burstable-4" => "Standard_D4ds_v6",
      "burstable-8" => "Standard_D8ds_v6",
      "standard-2" => "Standard_D2ds_v6",
      "standard-4" => "Standard_D4ds_v6",
      "standard-8" => "Standard_D8ds_v6",
      "standard-16" => "Standard_D16ds_v6",
      "standard-30" => "Standard_D32ds_v6",
    },
  }.freeze
  AZURE_BOOT_IMAGES = {
    "ubuntu-noble" => {publisher: "Canonical", offer: "ubuntu-24_04-lts", sku: "server", version: "latest"},
    "ubuntu-jammy" => {publisher: "Canonical", offer: "0001-com-ubuntu-server-jammy", sku: "22_04-lts-gen2", version: "latest"},
    "gpu-ubuntu-noble" => {publisher: "Canonical", offer: "ubuntu-24_04-lts", sku: "server", version: "latest"},
    "debian-12" => {publisher: "Debian", offer: "debian-12", sku: "12-gen2", version: "latest"},
    "almalinux-9" => {publisher: "almalinux", offer: "almalinux-x86_64", sku: "9-gen2", version: "latest"},
    "rocky-9" => {publisher: "resf", offer: "rockylinux-x86_64", sku: "9-base", version: "latest"},
  }.freeze

  def self.linode_plan(family, vcpu_count, gpu_count: 0, gpu_device: nil, size_name: nil, memory_gib: nil)
    gpu_suffix = gpu_count.to_i.positive? ? " with #{gpu_count} GPU(s)" : ""
    LINODE_PLANS.find {
      it.family == family &&
        it.vcpus == vcpu_count &&
        it.gpu_count == gpu_count.to_i &&
        it.gpu_device == gpu_device &&
        (size_name.nil? || it.size_name == size_name) &&
        (memory_gib.nil? || it.memory_gib == memory_gib)
    } || raise(Validation::ValidationFailed.new({size: "#{family}-#{vcpu_count}#{gpu_suffix} is not available on Linode"}))
  end

  def self.linode_instance_type_name(family, vcpu_count, gpu_count: 0, gpu_device: nil, size_name: nil, memory_gib: nil)
    linode_plan(family, vcpu_count, gpu_count:, gpu_device:, size_name:, memory_gib:).id
  rescue KeyError
    gpu_suffix = gpu_count.to_i.positive? ? " with #{gpu_count} GPU(s)" : ""
    raise Validation::ValidationFailed.new({size: "#{family}-#{vcpu_count}#{gpu_suffix} is not available on Linode"})
  end

  def self.linode_gpu_location?(location_name)
    LINODE_GPU_LOCATION_NAMES.include?(location_name.to_s)
  end

  def self.linode_image_name(boot_image)
    if boot_image.start_with?("kubernetes-")
      env_key = "LINODE_#{boot_image.upcase.tr("-.", "__")}_IMAGE"
      ENV.fetch(env_key, "linode/ubuntu24.04")
    elsif boot_image == "postgres-ubuntu-2204"
      ENV.fetch("LINODE_POSTGRES_IMAGE", "linode/ubuntu22.04")
    else
      LINODE_BOOT_IMAGES.fetch(boot_image)
    end
  rescue KeyError
    raise Validation::ValidationFailed.new({boot_image: "#{boot_image} is not available on Linode"})
  end

  def self.linode_boot_image?(boot_image)
    LINODE_BOOT_IMAGES.key?(boot_image) || boot_image.start_with?("kubernetes-") || boot_image == "postgres-ubuntu-2204"
  end

  def self.linode_plan_by_id(id)
    LINODE_PLANS.find { it.id == id }
  end

  def self.azure_plan(family, vcpu_count, gpu_count: 0, gpu_device: nil, size_name: nil, memory_gib: nil, location: nil)
    gpu_suffix = gpu_count.to_i.positive? ? " with #{gpu_count} GPU(s)" : ""
    plan = AZURE_PLANS.find {
      it.family == family &&
        it.vcpus == vcpu_count &&
        it.gpu_count == gpu_count.to_i &&
        it.gpu_device == gpu_device &&
        (size_name.nil? || it.size_name == size_name) &&
        (memory_gib.nil? || it.memory_gib == memory_gib)
    } || raise(Validation::ValidationFailed.new({size: "#{family}-#{vcpu_count}#{gpu_suffix} is not available on Azure"}))

    if (override_id = AZURE_LOCATION_PLAN_IDS.dig(azure_location_name(location), plan.size_name))
      plan = AzurePlan.new(override_id, plan.label, plan.family, plan.size_name, plan.vcpus, plan.memory_gib, plan.disk_gib, plan.monthly_price, plan.hourly_price, plan.gpu_count, plan.gpu_device, plan.billing_family)
    end

    plan
  end

  def self.azure_location_name(location)
    location.respond_to?(:name) ? location.name : location.to_s
  end

  def self.azure_plan_by_id(id)
    AZURE_PLANS.find { it.id == id }
  end

  def self.azure_image_reference(boot_image)
    image = if boot_image.start_with?("kubernetes-")
      AZURE_BOOT_IMAGES.fetch("ubuntu-noble")
    elsif boot_image == "postgres-ubuntu-2204"
      AZURE_BOOT_IMAGES.fetch("ubuntu-jammy")
    else
      AZURE_BOOT_IMAGES.fetch(boot_image)
    end
    image.transform_keys(&:to_s)
  rescue KeyError
    raise Validation::ValidationFailed.new({boot_image: "#{boot_image} is not available on Azure"})
  end

  def self.azure_boot_image?(boot_image)
    AZURE_BOOT_IMAGES.key?(boot_image) || boot_image.start_with?("kubernetes-") || boot_image == "postgres-ubuntu-2204"
  end

  def self.azure_vm_size_names(gpu: false)
    AZURE_PLANS
      .select { |plan| gpu ? plan.gpu_count.positive? : plan.gpu_count.zero? }
      .map(&:size_name)
      .uniq
  end

  def self.azure_vm_size_available?(vm_size, gpu: false)
    azure_vm_size_names(gpu:).include?(vm_size.display_name)
  end

  def self.linode_vm_size_names(gpu: false)
    LINODE_PLANS
      .select { |plan| gpu ? plan.gpu_count.positive? : plan.gpu_count.zero? }
      .map(&:size_name)
      .uniq
  end

  def self.linode_vm_size_available?(vm_size, gpu: false)
    linode_vm_size_names(gpu:).include?(vm_size.display_name)
  end

  def self.vm_size_options(location: nil, gpu: false)
    sizes = VmSizes.select { it.visible && it.arch == "x64" }
    return sizes.select { azure_vm_size_available?(it, gpu:) } if azure_location?(location)
    return sizes unless linode_location?(location)

    sizes.select { linode_vm_size_available?(it, gpu:) }
  end

  def self.kubernetes_worker_size_options(location: nil)
    sizes = VmSizes.select { it.visible && it.arch == "x64" && it.family == "standard" && it.vcpus <= 16 }
    if azure_location?(location)
      azure_standard_sizes = AZURE_PLANS
        .select { it.family == "standard" && it.gpu_count.zero? }
        .map(&:size_name)
        .uniq
      return sizes.select { azure_standard_sizes.include?(it.display_name) }
    end
    return sizes unless linode_location?(location)

    linode_standard_sizes = LINODE_PLANS
      .select { it.family == "standard" && it.gpu_count.zero? }
      .map(&:size_name)
      .uniq
    sizes.select { linode_standard_sizes.include?(it.display_name) }
  end

  MACHINE_IMAGE_SEARCH_LOCATIONS = {
    Location::HETZNER_FSN1_ID => [Location::HETZNER_FSN1_ID, Location::HETZNER_HEL1_ID],
    Location::HETZNER_HEL1_ID => [Location::HETZNER_HEL1_ID, Location::HETZNER_FSN1_ID],
  }.each_value(&:freeze).freeze

  def self.machine_image_search_locations(location_id)
    MACHINE_IMAGE_SEARCH_LOCATIONS.fetch(location_id, [location_id])
  end

  def self.kubernetes_upgrade_candidate(version)
    {
      "v1.33" => "v1.34",
      "v1.34" => "v1.35",
      "v1.35" => "v1.36",
    }.freeze[version]
  end

  def self.families
    Option::VmFamilies.select { it.visible }
  end

  def self.aws_instance_type_name(family, vcpu_count)
    suffix = if vcpu_count == 1
      "medium"
    elsif vcpu_count == 2
      "large"
    elsif vcpu_count == 4
      "xlarge"
    else
      "#{vcpu_count / 4}xlarge"
    end

    "#{family}.#{suffix}"
  end

  def self.gcp_instance_type_name(family, vcpu_count)
    "#{family}-#{vcpu_count}-lssd"
  end

  def self.vring_workers(vcpus)
    [1, vcpus / 2].max
  end

  generic_local_storage_vcpus = [2, 4, 8, 16, 32, 48, 64]
  rgd_families_local_storage_vcpus = [1, *generic_local_storage_vcpus]
  ebs_families_vcpus = [2, 4, 8, 16, 32, 64]
  i_families_local_storage_vcpus = [2, 4, 8, 16, 32, 48, 64, 96]
  ie_families_local_storage_vcpus = [2, 4, 8, 12, 24, 48, 72, 96]

  AWS_FAMILY_VM_CONFIG = {
    # Compute optimized: vcpu * 2 memory
    "c6gd" => {vcpus: generic_local_storage_vcpus, mem_ratio: 2, arch: "arm64"},
    "c7gd" => {vcpus: generic_local_storage_vcpus, mem_ratio: 2, arch: "arm64"},
    "c8gd" => {vcpus: generic_local_storage_vcpus, mem_ratio: 2, arch: "arm64"},
    "c6id" => {vcpus: generic_local_storage_vcpus, mem_ratio: 2, arch: "x64"},
    "c8id" => {vcpus: generic_local_storage_vcpus, mem_ratio: 2, arch: "x64"},
    # General purpose: vcpu * 4 memory
    "m6a" => {vcpus: ebs_families_vcpus, mem_ratio: 4, arch: "x64"},
    "m7a" => {vcpus: ebs_families_vcpus, mem_ratio: 4, arch: "x64"},
    "m7i" => {vcpus: ebs_families_vcpus, mem_ratio: 4, arch: "x64"},
    "m7g" => {vcpus: ebs_families_vcpus, mem_ratio: 4, arch: "arm64"},
    "m8g" => {vcpus: ebs_families_vcpus, mem_ratio: 4, arch: "arm64"},
    "m6gd" => {vcpus: generic_local_storage_vcpus, mem_ratio: 4, arch: "arm64"},
    "m7gd" => {vcpus: generic_local_storage_vcpus, mem_ratio: 4, arch: "arm64"},
    "m8gd" => {vcpus: generic_local_storage_vcpus, mem_ratio: 4, arch: "arm64"},
    "m6id" => {vcpus: generic_local_storage_vcpus, mem_ratio: 4, arch: "x64"},
    "m8id" => {vcpus: generic_local_storage_vcpus, mem_ratio: 4, arch: "x64"},
    # Storage optimized: vcpu * 8 memory
    "i8g" => {vcpus: i_families_local_storage_vcpus, mem_ratio: 8, arch: "arm64"},
    "i7i" => {vcpus: i_families_local_storage_vcpus, mem_ratio: 8, arch: "x64"},
    "i8ge" => {vcpus: ie_families_local_storage_vcpus, mem_ratio: 8, arch: "arm64"},
    "i7ie" => {vcpus: ie_families_local_storage_vcpus, mem_ratio: 8, arch: "x64"},
    # Memory optimized: vcpu * 8 memory
    "r6gd" => {vcpus: rgd_families_local_storage_vcpus, mem_ratio: 8, arch: "arm64"},
    "r7gd" => {vcpus: rgd_families_local_storage_vcpus, mem_ratio: 8, arch: "arm64"},
    "r8gd" => {vcpus: rgd_families_local_storage_vcpus, mem_ratio: 8, arch: "arm64"},
    "r6id" => {vcpus: generic_local_storage_vcpus, mem_ratio: 8, arch: "x64"},
    "r8id" => {vcpus: generic_local_storage_vcpus, mem_ratio: 8, arch: "x64"},
  }.freeze

  AWS_FAMILY_OPTIONS = AWS_FAMILY_VM_CONFIG.keys.freeze
  GCP_FAMILY_OPTIONS = ["c4a-standard", "c4a-highmem"].freeze

  non_storage_optimized_vm_storage_size_options = {1 => [59], 2 => [118], 4 => [237], 8 => [474], 16 => [950], 32 => [1900], 48 => [2850], 64 => [3800], 96 => [5700], 128 => [7600], 192 => [11400]}
  AWS_STORAGE_SIZE_OPTIONS = {
    "c6gd" => non_storage_optimized_vm_storage_size_options,
    "c6id" => non_storage_optimized_vm_storage_size_options,
    "c7gd" => non_storage_optimized_vm_storage_size_options,
    "c8gd" => non_storage_optimized_vm_storage_size_options,
    "c8id" => non_storage_optimized_vm_storage_size_options,
    "m6a" => non_storage_optimized_vm_storage_size_options,
    "m6id" => non_storage_optimized_vm_storage_size_options,
    "m6gd" => non_storage_optimized_vm_storage_size_options,
    "m7a" => non_storage_optimized_vm_storage_size_options,
    "m7i" => non_storage_optimized_vm_storage_size_options,
    "m7g" => non_storage_optimized_vm_storage_size_options,
    "m7gd" => non_storage_optimized_vm_storage_size_options,
    "m8g" => non_storage_optimized_vm_storage_size_options,
    "m8gd" => non_storage_optimized_vm_storage_size_options,
    "m8id" => non_storage_optimized_vm_storage_size_options,
    "i8g" => {2 => [468], 4 => [937], 8 => [1875], 16 => [3750], 32 => [7500], 48 => [11250], 64 => [15000], 96 => [22500]},
    "i8ge" => {2 => [1250], 4 => [2500], 8 => [5000], 12 => [7500], 24 => [15000], 48 => [30000], 72 => [45000], 96 => [60000]},
    "i7i" => {2 => [468], 4 => [937], 8 => [1875], 16 => [3750], 32 => [7500], 48 => [11250], 64 => [15000], 96 => [22500]},
    "i7ie" => {2 => [1250], 4 => [2500], 8 => [5000], 12 => [7500], 24 => [15000], 48 => [30000], 72 => [45000], 96 => [60000]},
    "r6gd" => non_storage_optimized_vm_storage_size_options,
    "r6id" => non_storage_optimized_vm_storage_size_options,
    "r7gd" => non_storage_optimized_vm_storage_size_options,
    "r8gd" => non_storage_optimized_vm_storage_size_options,
    "r8id" => non_storage_optimized_vm_storage_size_options,
  }.freeze

  gcp_c4a_storage = {4 => [375], 8 => [750], 16 => [1500], 32 => [2250], 48 => [3750], 64 => [5250], 72 => [6000]}
  GCP_STORAGE_SIZE_OPTIONS = {
    "c4a-standard" => gcp_c4a_storage,
    "c4a-highmem" => gcp_c4a_storage,
  }.freeze

  BootImage = Struct.new(:name, :display_name)
  BootImages = [
    ["gpu-ubuntu-noble", "Ubuntu 24.04 LTS for GPU VMs"],
    ["ubuntu-noble", "Ubuntu Noble 24.04 LTS"],
    ["ubuntu-jammy", "Ubuntu Jammy 22.04 LTS"],
    ["debian-12", "Debian 12"],
    ["almalinux-9", "AlmaLinux 9"],
    ["rocky-9", "Rocky Linux 9"],
  ].map { |args| BootImage.new(*args) }.freeze

  VmFamily = Data.define(:name, :ui_descriptor, :visible, :require_shared_slice) do
    def display_name
      name.capitalize
    end
  end

  VmFamilies = [
    ["nanode", "Shared CPU Starter", true, true],
    ["standard", "Dedicated CPU", true, false],
    ["premium", "Dedicated Premium CPU", false, false],
    ["burstable", "Shared CPU", true, true],
  ].map { |args| VmFamily.new(*args) }

  IoLimits = Data.define(:max_read_mbytes_per_sec, :max_write_mbytes_per_sec)
  NO_IO_LIMITS = IoLimits.new(nil, nil)

  VmSize = Struct.new(:name, :family, :vcpus, :cpu_percent_limit, :cpu_burst_percent_limit, :memory_gib, :storage_size_options, :io_limits, :vring_workers, :visible, :arch) do
    alias_method :display_name, :name
  end
  VmSizes = [
    VmSize.new("nanode-1", "nanode", 1, 50, 50, 1, [25], IoLimits.new(50, 50), 1, true, "x64"),
    VmSize.new("nanode-2", "nanode", 1, 50, 50, 2, [50], IoLimits.new(50, 50), 1, true, "x64"),
    VmSize.new("nanode-4", "nanode", 2, 100, 100, 4, [80], IoLimits.new(100, 100), 1, true, "x64"),
    VmSize.new("nanode-8", "nanode", 4, 200, 200, 8, [160], IoLimits.new(200, 200), 1, true, "x64")
  ].concat([2, 4, 8, 16, 30, 60].map {
    storage_size_options = [it * 20, it * 40]
    VmSize.new("standard-#{it}", "standard", it, it * 100, 0, it * 4, storage_size_options, NO_IO_LIMITS, vring_workers(it), true, "x64")
  }).concat([2, 4, 8, 16, 30, 60].map {
    storage_size_options = [it * 20, it * 40]
    VmSize.new("standard-#{it}", "standard", it, it * 100, 0, (it * 3.2).to_i, storage_size_options, NO_IO_LIMITS, vring_workers(it), false, "arm64")
  }).concat([2, 4, 8, 16, 30].map {
    storage_size_options = [it * 20, it * 40]
    VmSize.new("premium-#{it}", "premium", it, it * 100, 0, it * 4, storage_size_options, NO_IO_LIMITS, vring_workers(it), false, "x64")
  }).concat([1, 2, 4, 8].map {
    storage_size_options = [it * 10, it * 20]
    io_limits = IoLimits.new(it * 50, it * 50)
    VmSize.new("burstable-#{it}", "burstable", it, it * 50, it * 50, it * 2, storage_size_options, io_limits, 1, true, "x64")
  }).concat([1, 2, 4, 8].map {
    storage_size_options = [it * 10, it * 20]
    io_limits = IoLimits.new(it * 50, it * 50)
    VmSize.new("burstable-#{it}", "burstable", it, it * 50, it * 50, (it * 1.6).to_i, storage_size_options, io_limits, 1, false, "arm64")
  }).concat(AWS_FAMILY_VM_CONFIG.flat_map { |family, cfg|
    cfg[:vcpus].map { |vcpu|
      VmSize.new(aws_instance_type_name(family, vcpu), family, vcpu, vcpu * 100, 0,
        vcpu * cfg[:mem_ratio], AWS_STORAGE_SIZE_OPTIONS[family][vcpu], NO_IO_LIMITS, nil, false, cfg[:arch])
    }
  }).concat(["c4a-standard"].product([4, 8, 16, 32, 48, 64, 72]).map { |family, vcpu|
    VmSize.new("#{family}-#{vcpu}", family, vcpu, vcpu * 100, 0, vcpu * 4, GCP_STORAGE_SIZE_OPTIONS[family][vcpu], NO_IO_LIMITS, nil, false, "arm64")
  }).concat(["c4a-highmem"].product([4, 8, 16, 32, 48, 64, 72]).map { |family, vcpu|
    VmSize.new("#{family}-#{vcpu}", family, vcpu, vcpu * 100, 0, vcpu * 8, GCP_STORAGE_SIZE_OPTIONS[family][vcpu], NO_IO_LIMITS, nil, false, "arm64")
  }).freeze

  # Postgres Global Options
  PostgresFlavorOption = Data.define(:name, :brand, :title, :description)
  POSTGRES_FLAVOR_OPTIONS = [
    [PostgresResource::Flavor::STANDARD, "postgresql", "PostgreSQL Database", "Get started by creating a new PostgreSQL database which is managed by the LayerRail team. It's a good choice for general purpose databases."],
    [PostgresResource::Flavor::PARADEDB, "paradedb", "ParadeDB PostgreSQL Database", "ParadeDB is an Elasticsearch alternative built on Postgres. ParadeDB instances are managed by the ParadeDB team and are optimal for search and analytics workloads."],
    [PostgresResource::Flavor::LANTERN, "lantern", "Lantern PostgreSQL Database", "Lantern is a PostgreSQL-based vector database designed specifically for building AI applications. Lantern instances are managed by the Lantern team and are optimal for AI workloads."],
  ].to_h { |args| [args[0], PostgresFlavorOption.new(*args)] }.freeze

  PostgresFamilyOption = Data.define(:name, :description)
  POSTGRES_FAMILY_OPTIONS = [
    ["standard", "Dedicated CPU"],
    ["hobby", "Shared CPU"],
    ["m6gd", "General Purpose, Graviton2"],
    ["m6id", "General Purpose, Intel Xeon"],
    ["m7gd", "General Purpose, Graviton3"],
    ["m8gd", "General Purpose, Graviton4"],
    ["m8id", "General Purpose, Intel Xeon"],
    ["c6gd", "Compute Optimized, Graviton2"],
    ["c6id", "Compute Optimized, Intel Xeon"],
    ["c7gd", "Compute Optimized, Graviton3"],
    ["c8gd", "Compute Optimized, Graviton4"],
    ["c8id", "Compute Optimized, Intel Xeon"],
    ["i7i", "Storage Optimized, Intel Xeon"],
    ["i7ie", "Storage Optimized, Intel Xeon"],
    ["i8g", "Storage Optimized, Graviton4"],
    ["i8ge", "Storage Optimized, Graviton4"],
    ["r6gd", "Memory Optimized, Graviton2"],
    ["r6id", "Memory Optimized, Intel Xeon"],
    ["r7gd", "Memory Optimized, Graviton3"],
    ["r8gd", "Memory Optimized, Graviton4"],
    ["r8id", "Memory Optimized, Intel Xeon"],
    ["c4a-standard", "General Purpose, Google Axion"],
    ["c4a-highmem", "Memory Optimized, Google Axion"],
  ].to_h { |args| [args[0], PostgresFamilyOption.new(*args)] }.freeze

  PostgresSizeOption = Data.define(:name, :family, :vcpu_count, :memory_gib)
  POSTGRES_SIZE_OPTIONS = [
    ["standard", 2, 8],
    ["standard", 4, 16],
    ["standard", 8, 32],
    ["standard", 16, 64],
    ["standard", 30, 120],
    ["standard", 60, 240],
    ["hobby", 1, 2],
    ["hobby", 2, 4],
    ["c6gd", 2, 4],
    ["c6gd", 4, 8],
    ["c6gd", 8, 16],
    ["c6gd", 16, 32],
    ["c6gd", 32, 64],
    ["c6gd", 48, 96],
    ["c6gd", 64, 128],
    ["c6id", 2, 4],
    ["c6id", 4, 8],
    ["c6id", 8, 16],
    ["c6id", 16, 32],
    ["c6id", 32, 64],
    ["c6id", 48, 96],
    ["c6id", 64, 128],
    ["c7gd", 2, 4],
    ["c7gd", 4, 8],
    ["c7gd", 8, 16],
    ["c7gd", 16, 32],
    ["c7gd", 32, 64],
    ["c7gd", 48, 96],
    ["c7gd", 64, 128],
    ["c8gd", 2, 4],
    ["c8gd", 4, 8],
    ["c8gd", 8, 16],
    ["c8gd", 16, 32],
    ["c8gd", 32, 64],
    ["c8gd", 48, 96],
    ["c8gd", 64, 128],
    ["c8id", 2, 4],
    ["c8id", 4, 8],
    ["c8id", 8, 16],
    ["c8id", 16, 32],
    ["c8id", 32, 64],
    ["c8id", 48, 96],
    ["c8id", 64, 128],
    ["m6id", 2, 8],
    ["m6id", 4, 16],
    ["m6id", 8, 32],
    ["m6id", 16, 64],
    ["m6id", 32, 128],
    ["m6id", 48, 192],
    ["m6id", 64, 256],
    ["m6gd", 2, 8],
    ["m6gd", 4, 16],
    ["m6gd", 8, 32],
    ["m6gd", 16, 64],
    ["m6gd", 32, 128],
    ["m6gd", 48, 192],
    ["m6gd", 64, 256],
    ["m7gd", 2, 8],
    ["m7gd", 4, 16],
    ["m7gd", 8, 32],
    ["m7gd", 16, 64],
    ["m7gd", 32, 128],
    ["m7gd", 48, 192],
    ["m7gd", 64, 256],
    ["m8gd", 2, 8],
    ["m8gd", 4, 16],
    ["m8gd", 8, 32],
    ["m8gd", 16, 64],
    ["m8gd", 32, 128],
    ["m8gd", 48, 192],
    ["m8gd", 64, 256],
    ["m8id", 2, 8],
    ["m8id", 4, 16],
    ["m8id", 8, 32],
    ["m8id", 16, 64],
    ["m8id", 32, 128],
    ["m8id", 48, 192],
    ["m8id", 64, 256],
    ["i8g", 2, 16],
    ["i8g", 4, 32],
    ["i8g", 8, 64],
    ["i8g", 16, 128],
    ["i8g", 32, 256],
    ["i8g", 48, 384],
    ["i8g", 64, 512],
    ["i8g", 96, 768],
    ["i8ge", 2, 16],
    ["i8ge", 4, 32],
    ["i8ge", 8, 64],
    ["i8ge", 12, 96],
    ["i8ge", 24, 192],
    ["i8ge", 48, 384],
    ["i8ge", 72, 576],
    ["i8ge", 96, 768],
    ["i7i", 2, 16],
    ["i7i", 4, 32],
    ["i7i", 8, 64],
    ["i7i", 16, 128],
    ["i7i", 32, 256],
    ["i7i", 48, 384],
    ["i7i", 64, 512],
    ["i7i", 96, 768],
    ["i7ie", 2, 16],
    ["i7ie", 4, 32],
    ["i7ie", 8, 64],
    ["i7ie", 12, 96],
    ["i7ie", 24, 192],
    ["i7ie", 48, 384],
    ["i7ie", 72, 576],
    ["i7ie", 96, 768],
    ["r6gd", 1, 8],
    ["r6gd", 2, 16],
    ["r6gd", 4, 32],
    ["r6gd", 8, 64],
    ["r6gd", 16, 128],
    ["r6gd", 32, 256],
    ["r6gd", 48, 384],
    ["r6gd", 64, 512],
    ["r6id", 2, 16],
    ["r6id", 4, 32],
    ["r6id", 8, 64],
    ["r6id", 16, 128],
    ["r6id", 32, 256],
    ["r6id", 48, 384],
    ["r6id", 64, 512],
    ["r7gd", 1, 8],
    ["r7gd", 2, 16],
    ["r7gd", 4, 32],
    ["r7gd", 8, 64],
    ["r7gd", 16, 128],
    ["r7gd", 32, 256],
    ["r7gd", 48, 384],
    ["r7gd", 64, 512],
    ["r8gd", 1, 8],
    ["r8gd", 2, 16],
    ["r8gd", 4, 32],
    ["r8gd", 8, 64],
    ["r8gd", 16, 128],
    ["r8gd", 32, 256],
    ["r8gd", 48, 384],
    ["r8gd", 64, 512],
    ["r8id", 2, 16],
    ["r8id", 4, 32],
    ["r8id", 8, 64],
    ["r8id", 16, 128],
    ["r8id", 32, 256],
    ["r8id", 48, 384],
    ["r8id", 64, 512],
    ["c4a-standard", 4, 16],
    ["c4a-standard", 8, 32],
    ["c4a-standard", 16, 64],
    ["c4a-standard", 32, 128],
    ["c4a-standard", 48, 192],
    ["c4a-standard", 64, 256],
    ["c4a-standard", 72, 288],
    ["c4a-highmem", 4, 32],
    ["c4a-highmem", 8, 64],
    ["c4a-highmem", 16, 128],
    ["c4a-highmem", 32, 256],
    ["c4a-highmem", 48, 384],
    ["c4a-highmem", 64, 512],
    ["c4a-highmem", 72, 576],
  ].to_h do |args|
    name = if AWS_FAMILY_OPTIONS.include?(args[0])
      aws_instance_type_name(args[0], args[1])
    else
      "#{args[0]}-#{args[1]}"
    end

    [name, PostgresSizeOption.new(name, *args)]
  end.freeze

  POSTGRES_LEGACY_SIZE_OPTIONS = POSTGRES_SIZE_OPTIONS.merge([
    ["burstable-1", POSTGRES_SIZE_OPTIONS["hobby-1"]],
    ["burstable-2", POSTGRES_SIZE_OPTIONS["hobby-2"]],
  ].to_h).freeze

  LINODE_POSTGRES_SIZE_NAMES = %w[hobby-1 hobby-2 standard-2 standard-4].freeze
  AZURE_POSTGRES_SIZE_NAMES = %w[hobby-2 standard-2 standard-4].freeze

  def self.azure_location?(location)
    location&.provider == "azure" || Config.compute_provider == "azure"
  end

  def self.linode_location?(location)
    location&.provider == "linode" || Config.compute_provider == "linode"
  end

  def self.postgres_family_options(location: nil)
    return POSTGRES_FAMILY_OPTIONS.select { |name,| %w[standard hobby].include?(name) } if azure_location?(location)
    return POSTGRES_FAMILY_OPTIONS unless linode_location?(location)

    POSTGRES_FAMILY_OPTIONS.select { |name,| %w[standard hobby].include?(name) }
  end

  def self.postgres_size_options(location: nil)
    return POSTGRES_SIZE_OPTIONS.select { |name,| AZURE_POSTGRES_SIZE_NAMES.include?(name) } if azure_location?(location)
    return POSTGRES_SIZE_OPTIONS unless linode_location?(location)

    POSTGRES_SIZE_OPTIONS.select { |name,| LINODE_POSTGRES_SIZE_NAMES.include?(name) }
  end

  def self.safe_azure_postgres_size_name(size_name)
    name = size_name.to_s.gsub("burstable", "hobby")
    return "hobby-2" if name == "hobby-1"
    return name if AZURE_POSTGRES_SIZE_NAMES.include?(name)

    parsed = POSTGRES_SIZE_OPTIONS[name]
    parsed&.family == "standard" ? "standard-4" : "hobby-2"
  end

  def self.safe_linode_postgres_size_name(size_name)
    name = size_name.to_s.gsub("burstable", "hobby")
    return name if LINODE_POSTGRES_SIZE_NAMES.include?(name)

    parsed = POSTGRES_SIZE_OPTIONS[name]
    parsed&.family == "standard" ? "standard-4" : "hobby-2"
  end

  POSTGRES_FAMILY_FALLBACK_CHAINS = [
    ["c6gd", "c7gd", "c8gd"],
    ["c6id", "c8id"],
    ["m6id", "m8id"],
    ["m6gd", "m7gd", "m8gd"],
    ["r6gd", "r7gd", "r8gd"],
    ["r6id", "r8id"],
  ].freeze

  def self.postgres_fallback_candidates(family)
    chain = POSTGRES_FAMILY_FALLBACK_CHAINS.find { it.include?(family) }
    chain ? chain - [family] : []
  end

  def self.postgres_family_rank(family)
    chain = POSTGRES_FAMILY_FALLBACK_CHAINS.find { it.include?(family) }
    chain ? chain.index(family) : -1
  end

  POSTGRES_STORAGE_SIZE_OPTIONS = [16, 32, 64, 128, 256, 512, 1024, 2048, 4096].freeze

  POSTGRES_VERSION_OPTIONS = {
    PostgresResource::Flavor::STANDARD => ["18", "17", "16"],
    PostgresResource::Flavor::PARADEDB => ["17", "16"],
    PostgresResource::Flavor::LANTERN => ["17", "16"],
  }

  PostgresHaOption = Data.define(:name, :standby_count, :description)
  POSTGRES_HA_OPTIONS = [
    [PostgresResource::HaType::NONE, 0, "No Standbys"],
    [PostgresResource::HaType::ASYNC, 1, "1 Standby"],
    [PostgresResource::HaType::SYNC, 2, "2 Standbys"],
  ].to_h { |args| [args[0], PostgresHaOption.new(*args)] }.freeze

  POSTGRES_LOG_STREAM_OPTIONS = %w[postgres pgbouncer upgrade].freeze
  POSTGRES_LOG_SERVER_ROLE_OPTIONS = %w[primary standby].freeze
  POSTGRES_LOG_LEVEL_OPTIONS = %w[DEBUG INFO WARN ERROR FATAL].freeze

  AWS_LOCATIONS = ["us-west-2", "us-east-1", "us-east-2", "ap-southeast-2", "eu-west-1", "eu-central-1"].freeze

  KubernetesCPOption = Struct.new(:cp_node_count, :title, :explanation)
  KubernetesCPOptions = [[1, "1 Node", "Single control plane node without resilience"],
    [3, "3 Nodes", "Three control plane nodes with resilience"]].map {
    KubernetesCPOption.new(*it)
  }.freeze
end
