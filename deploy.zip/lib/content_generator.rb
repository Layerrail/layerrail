# frozen_string_literal: true

module ContentGenerator
  module Vm
    def self.location(location)
      location.ui_name
    end

    def self.ssh_public_key(ssh_public_key)
      ssh_public_key.name
    end

    def self.private_subnet(location, private_subnet)
      private_subnet[:display_name]
    end

    def self.enable_ipv4(location, value)
      unit_price = BillingRate.unit_price_from_resource_properties("IPAddress", "IPv4", location.name)
      return "Enable Public IPv4 (included)" if unit_price.to_f.zero?

      "Enable Public IPv4 ($#{"%.2f" % (unit_price * 60 * 672)}/mo)"
    end

    def self.family(location, family)
      vm_family = Option::VmFamilies.find { it.name == family }
      [
        vm_family.display_name,
        vm_family.ui_descriptor,
      ]
    end

    def self.size(location, family, size)
      size = Option::VmSizes.find { it.display_name == size }
      if location.linode? || location.azure?
        plan = location.linode? ? Option.linode_plan(family, size.vcpus, size_name: size.display_name) : Option.azure_plan(family, size.vcpus, size_name: size.display_name, location:)
        markup = location.linode? ? Option::LINODE_MARKUP : Option::AZURE_MARKUP
        return [
          size.display_name,
          "#{plan.vcpus} vCPUs / #{plan.memory_gib} GB RAM / #{plan.disk_gib} GB storage",
          "$#{"%.2f" % (plan.monthly_price * markup)}/mo",
          "$#{"%.3f" % (plan.hourly_price * markup)}/hour",
        ]
      end

      unit_price = BillingRate.unit_price_from_resource_properties("VmVCpu", family, location.name)
      [
        size.display_name,
        "#{size.vcpus} vCPUs / #{size.memory_gib} GB RAM",
        "$#{"%.2f" % (size.vcpus * unit_price * 60 * 672)}/mo",
        "$#{"%.3f" % (size.vcpus * unit_price * 60)}/hour",
      ]
    end

    def self.linode_gpu_size(location, family, size)
      size = Option::VmSizes.find { it.display_name == size }
      return self.size(location, family, size.display_name) unless location.linode?

      plan = Option.linode_plan(family, size.vcpus, gpu_count: 1, gpu_device: Option::LINODE_GPU_DEVICE, size_name: size.display_name)

      [
        plan.label,
        "#{plan.vcpus} vCPUs / #{plan.memory_gib} GB RAM / #{plan.disk_gib} GB storage",
        "$#{"%.2f" % (plan.monthly_price * Option::LINODE_MARKUP)}/mo",
        "$#{"%.3f" % (plan.hourly_price * Option::LINODE_MARKUP)}/hour",
      ]
    end

    def self.storage_size(location, family, vm_size, storage_size)
      storage_size = storage_size.to_i
      unit_price = BillingRate.unit_price_from_resource_properties("VmStorage", family, location.name)
      monthly_price = unit_price.to_f.zero? ? "Included" : "$#{"%.2f" % (storage_size * unit_price * 60 * 672)}/mo"
      hourly_price = unit_price.to_f.zero? ? "" : "$#{"%.3f" % (storage_size * unit_price * 60)}/hour"

      [
        "#{storage_size}GB",
        nil,
        monthly_price,
        hourly_price,
      ]
    end

    def self.gpu(location, family, gpu)
      gpu = gpu.split(":")
      gpu_count = gpu[0].to_i

      unit_price = (gpu_count == 0) ? 0 : BillingRate.unit_price_from_resource_properties("Gpu", gpu[1], location.name)

      [
        (gpu_count == 0) ? "No GPU" : "#{gpu_count}x #{PciDevice.device_name(gpu[1])}",
        nil,
        "$#{"%.2f" % (gpu_count * unit_price * 60 * 672)}/mo",
        "$#{"%.3f" % (gpu_count * unit_price * 60)}/hour",
      ]
    end

    def self.linode_gpu(location, family, gpu)
      gpu_count, device = gpu.split(":", 2)
      gpu_count = gpu_count.to_i
      return self.gpu(location, family, gpu) unless location.linode? && gpu_count.positive?
      plan = Option::LINODE_PLANS.find { it.family == family && it.gpu_count == gpu_count && it.gpu_device == device } ||
        Option.linode_plan(family, 4, gpu_count:, gpu_device: device)

      [
        "NVIDIA #{plan.label}",
        "#{plan.memory_gib} GB RAM / 20 GB VRAM / #{plan.disk_gib} GB storage",
        "Included",
        "",
      ]
    end

    def self.boot_image(boot_image)
      Option::BootImages.find { it.name == boot_image }.display_name
    end
  end

  module Postgres
    def self.location(flavor, location)
      location.ui_name
    end

    def self.family(flavor, location, family)
      pg_family = Option::POSTGRES_FAMILY_OPTIONS[family]

      [
        pg_family.name,
        pg_family.description,
      ]
    end

    def self.size(flavor, location, family, size)
      size = Option::POSTGRES_SIZE_OPTIONS[size]
      memory_gib = if location.linode? || location.azure?
        provider_family = (family == "hobby") ? "burstable" : family
        if location.linode?
          Option.linode_plan(provider_family, size.vcpu_count).memory_gib
        else
          Option.azure_plan(provider_family, size.vcpu_count).memory_gib
        end
      else
        size.memory_gib
      end
      unit_price = BillingRate.unit_price_from_resource_properties("PostgresVCpu", "#{flavor}-#{family}", location.name, location.byoc)

      [
        size.name,
        "#{size.vcpu_count} vCPUs / #{memory_gib} GB RAM",
        "$#{"%.2f" % (size.vcpu_count * unit_price * 60 * 672)}/mo",
        "$#{"%.3f" % (size.vcpu_count * unit_price * 60)}/hour",
      ]
    end

    def self.storage_size(flavor, location, family, vm_size, storage_size)
      unit_price = BillingRate.unit_price_from_resource_properties("PostgresStorage", flavor, location.name, location.byoc)

      [
        "#{storage_size}GB",
        nil,
        "$#{"%.2f" % (storage_size.to_i * unit_price * 60 * 672)}/mo",
        "$#{"%.3f" % (storage_size.to_i * unit_price * 60)}/hour",
      ]
    end

    def self.version(flavor, version)
      "Postgres #{version}"
    end

    def self.ha_type(flavor, location, family, vm_size, storage_size, ha_type)
      vcpu_count = Option::POSTGRES_SIZE_OPTIONS[vm_size].vcpu_count
      ha_type = Option::POSTGRES_HA_OPTIONS[ha_type]
      compute_unit_price = BillingRate.unit_price_from_resource_properties("PostgresVCpu", "#{flavor}-#{family}", location.name, location.byoc)
      storage_unit_price = BillingRate.unit_price_from_resource_properties("PostgresStorage", flavor, location.name, location.byoc)
      standby_count = ha_type.standby_count

      [
        ha_type.description,
        "",
        "$#{"%.2f" % (standby_count * ((vcpu_count * compute_unit_price) + (storage_size.to_i * storage_unit_price)) * 60 * 672)}/mo",
        "$#{"%.3f" % (standby_count * ((vcpu_count * compute_unit_price) + (storage_size.to_i * storage_unit_price)) * 60)}/hour",
      ]
    end

    def self.partnership_notice(flavor)
      notice = {
        PostgresResource::Flavor::PARADEDB => [[
          "ParadeDB is an Elasticsearch alternative built on Postgres. ParadeDB instances are managed by the ParadeDB team and are optimal for search and analytics workloads.",
          "You can get ParadeDB specific support via email at <a href='mailto:support@paradedb.com' class='text-layerrail-600 font-semibold'>support@paradedb.com</a> or via Slack at <a href='https://join.slack.com/t/paradedbcommunity/shared_invite/zt-2lkzdsetw-OiIgbyFeiibd1DG~6wFgTQ' target='_blank' class='text-layerrail-600 font-semibold'>ParadeDB Community Slack</a>",
          "By creating a ParadeDB PostgreSQL database on LayerRail you consent to your contact information being shared with ParadeDB team.",
        ],
          "Accept <a href='https://paradedb.notion.site/Terms-of-Use-d17c9916a5b746fab86c274feb35da75' target='_blank' class='text-layerrail-600 font-semibold'>Terms of Service</a> and <a href='https://paradedb.notion.site/Privacy-Policy-a7ce333c45c8478fb03250dff7e573b7?pvs=4' target='_blank' class='text-layerrail-600 font-semibold'> Privacy Policy</a>"],
        PostgresResource::Flavor::LANTERN => [[
          "Lantern is a PostgreSQL-based vector database designed specifically for building AI applications. Lantern instances are managed by the Lantern team and are optimal for AI workloads.",
          "You can reach to Lantern team for support at <a href='mailto:support@lantern.dev' class='text-layerrail-600 font-semibold'>support@lantern.dev</a>",
          "By creating a Lantern PostgreSQL database on LayerRail you consent to your contact information being shared with Lantern team.",
        ],
          "Accept <a href='https://lantern.dev/legal/terms' target='_blank' class='text-layerrail-600 font-semibold'>Terms of Service</a> and <a href='https://lantern.dev/legal/privacy' target='_blank' class='text-layerrail-600 font-semibold'> Privacy Policy</a>"],
      }

      notice[flavor]
    end
  end

  module LoadBalancer
    def self.select_option(select_option)
      select_option[:display_name]
    end

    def self.enable_ssl_certificate(ssl_certificate)
      "Enable SSL Certificate"
    end
  end

  module KubernetesCluster
    def self.location(location)
      location.ui_name
    end

    def self.cp_nodes(location, cp_nodes)
      cp_node_price = 2 * BillingRate.unit_price_from_resource_properties("KubernetesControlPlaneVCpu", "standard", location.name)
      data = Option::KubernetesCPOptions.find { it.cp_node_count == cp_nodes }
      [
        data.title,
        data.explanation,
        "$#{"%.2f" % (cp_nodes * cp_node_price * 60 * 672)}/mo",
        "$#{"%.3f" % (cp_nodes * cp_node_price * 60)}/hour",
      ]
    end

    def self.worker_size(location, size)
      worker_size = Option::VmSizes.find { it.display_name == size }

      [
        worker_size.display_name,
        "#{worker_size.vcpus} vCPUs / #{worker_size.memory_gib} GB RAM / #{worker_size.storage_size_options.first} GB NVMe Storage",
        "$#{"%.2f" % monthly_price(location, worker_size)}/mo",
        "$#{"%.3f" % hourly_price(location, worker_size)}/hour",
      ]
    end

    def self.worker_nodes(location, size, worker_nodes)
      worker_size = Option::VmSizes.find { it.display_name == size }

      "#{worker_nodes[:display_name]} - $#{"%.2f" % (worker_nodes[:value] * monthly_price(location, worker_size))}/mo ($#{"%.3f" % (worker_nodes[:value] * hourly_price(location, worker_size))}/hour)"
    end

    def self.node_price(location, worker_size)
      worker_size.vcpus * BillingRate.unit_price_from_resource_properties("KubernetesWorkerVCpu", "standard", location.name) +
        worker_size.storage_size_options.first * BillingRate.unit_price_from_resource_properties("KubernetesWorkerStorage", "standard", location.name)
    end

    def self.hourly_price(location, worker_size)
      node_price(location, worker_size) * 60
    end

    def self.monthly_price(location, worker_size)
      node_price(location, worker_size) * 60 * 672
    end

    def self.version(version)
      "Kubernetes #{version}"
    end
  end

  module PrivateLocation
    def self.select_option(select_option)
      select_option[:display_name]
    end
  end
end
