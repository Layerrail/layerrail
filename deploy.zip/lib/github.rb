# frozen_string_literal: true

require "octokit"
require "jwt"
require "yaml"

Octokit.configure do |c|
  c.connection_options = {
    request: {
      open_timeout: 5,
      timeout: 5,
    },
  }
end

module Github
  MINUTE_BILLING_RATE_IDS = BillingRate.from_resource_type("GitHubRunnerMinutes").map { it["id"] }.freeze

  def self.oauth_client
    Octokit::Client.new(client_id: Config.github_app_client_id, client_secret: Config.github_app_client_secret)
  end

  def self.app_client
    current = Time.now.to_i
    private_key = OpenSSL::PKey::RSA.new(Config.github_app_private_key.to_s.gsub("\\n", "\n"))
    key = {
      iat: current,
      exp: current + (8 * 60),
      iss: Config.github_app_id,
    }
    bearer_token = JWT.encode(key, private_key, "RS256")

    Octokit::Client.new(bearer_token:, per_page: 100)
  end

  def self.installation_client(installation_id, auto_paginate: false, per_page: 100)
    access_token = installation_access_token(installation_id)
    Octokit::Client.new(access_token:, auto_paginate:, per_page:)
  end

  def self.installation_access_token(installation_id)
    app_client.create_app_installation_access_token(installation_id)[:token]
  end

  # :nocov:
  def self.freeze
    runner_labels
    super
  end
  # :nocov:

  def self.runner_labels
    @runner_labels ||= begin
      labels = YAML.load_file("config/github_runner_labels.yml").to_h { [it["name"], it] }
      add_legacy_runner_aliases(labels)
      labels = linode_runner_labels(labels) if Config.compute_provider == "linode"
      labels.transform_values do |v|
        new = resolve_runner_label(labels, v)
        new["vm_size"] = "#{new["family"]}-#{new["vcpus"]}"
        Validation.validate_vm_size(new["vm_size"], new["arch"])
        new
      end.freeze
    end
  end

  def self.add_legacy_runner_aliases(labels)
    labels.keys.grep(/\Alayerrail/).each do |name|
      legacy_name = name.sub(/\Alayerrail/, "ubicloud")
      labels[legacy_name] ||= {"name" => legacy_name, "alias_for" => name}
    end
  end

  def self.linode_runner_labels(labels)
    labels.select do |_name, label|
      target = resolve_runner_label(labels, label)
      next false unless target
      next false unless target["family"] == "standard" && target["arch"] == "x64"

      begin
        Option.linode_plan(target["family"], target["vcpus"])
        true
      rescue Validation::ValidationFailed
        false
      end
    end
  end

  def self.resolve_runner_label(labels, label)
    seen = {}
    while label && (alias_for = label["alias_for"])
      raise "Circular GitHub runner label alias: #{alias_for}" if seen[alias_for]

      seen[alias_for] = true
      label = labels[alias_for]
    end
    label
  end
end
