# frozen_string_literal: true

module ResourceMethods
  def self.configure(model, etc_type: false, redacted_columns: nil, encrypted_columns: nil, referencing: nil)
    model.instance_exec do
      @ubid_type = if referencing
        include NoSetUuid

        singleton_class.instance_exec do
          undef_method :generate_ubid
          undef_method :generate_uuid
          undef_method :new_with_id
        end

        referencing
      elsif etc_type
        UBID::TYPE_ETC
      else
        # Adapted from sequel/model/inflections.rb's underscore, to convert
        # class names into symbols
        lookup_name = name.gsub(/([A-Z]+)([A-Z][a-z])/, '\1_\2').gsub(/([a-z\d])([A-Z])/, '\1_\2').tr("-", "_").upcase
        UBID.const_get(:"TYPE_#{lookup_name}")
      end

      @ubid_format = /\A#{ubid_type}[a-tv-z0-9]{24}\z/
      encrypted_columns_with_opts = case encrypted_columns
      when nil then {}
      when Hash then encrypted_columns
      when Array then encrypted_columns.each_with_object({}) { |col, h| h[col] = {} }
      else {encrypted_columns => {}}
      end
      @encrypted_columns = encrypted_columns_with_opts.keys.freeze
      @redacted_columns = (Array(redacted_columns) + @encrypted_columns).freeze

      unless @encrypted_columns.empty?
        plugin :column_encryption do |enc|
          encrypted_columns_with_opts.each do |col, opts|
            enc.column col, **opts
          end
        end
      end
    end
  end

  module NoSetUuid
    def set_uuid
      self
    end
  end

  module InstanceMethods
    def freeze
      ubid
      super
    end

    def ubid
      @ubid ||= UBID.to_ubid(id)
    end

    def admin_label
      defined?(name) ? name : ubid
    end

    def to_s
      inspect_prefix
    end

    def inspect_pk
      ubid if id
    end

    def before_validation
      set_uuid
      super
    end

    def set_uuid
      self.id ||= self.class.generate_uuid if new?
      self
    end

    def validate
      super

      if self.class.ubid_format.match?(values[:name])
        errors.add(:name, "cannot be exactly 26 numbers/lowercase characters starting with #{self.class.ubid_type} to avoid overlap with id format")
      end
    end

    INSPECT_CONVERTERS = {
      "uuid" => lambda { |v| UBID.to_ubid(v) },
      "cidr" => :to_s.to_proc,
      "inet" => :to_s.to_proc,
      "numeric" => :to_f.to_proc,
      "timestamp with time zone" => lambda { |v| v.strftime("%F %T") },
    }.freeze
    def inspect_values_hash
      inspect_values = {}
      sch = db_schema
      @values.except(*self.class.redacted_columns).each do |k, v|
        next if k == :id

        inspect_values[k] = if v
          if (converter = INSPECT_CONVERTERS[sch.dig(k, :db_type)])
            converter.call(v)
          else
            v
          end
        else
          v
        end
      end

      inspect_values
    end

    def inspect_values
      inspect_values_hash.inspect
    end

    NON_ARCHIVED_MODELS = ["ArchivedRecord", "Semaphore"].freeze
    def before_destroy
      model_name = self.class.name
      unless NON_ARCHIVED_MODELS.include?(model_name)
        model_values = values.merge(model_name:)

        self.class.encrypted_columns.each do |key|
          model_values.delete(key)
        end

        ArchivedRecord.create(model_name:, model_values:)
      end

      super
    end
  end

  module DatasetMethods
    def destroy
      DB.ignore_duplicate_queries do
        super
      end
    end
  end

  module ClassMethods
    attr_reader :ubid_type

    attr_reader :ubid_format

    attr_reader :encrypted_columns

    attr_reader :redacted_columns

    def [](arg)
      if arg.is_a?(UBID)
        super(arg.to_uuid)
      elsif arg.is_a?(String) && arg.bytesize == 26
        if (uuid = UBID.to_uuid(arg))
          super(uuid)
        end
      else
        super
      end
    end

    def generate_ubid
      UBID.generate(ubid_type)
    end

    def generate_uuid
      generate_ubid.to_uuid
    end

    def create_with_id(id_or_model_object, **)
      raise "nil id passed to create_with_id" unless id_or_model_object
      obj = new(**)
      obj.id = id_or_model_object.is_a?(String) ? id_or_model_object : id_or_model_object.id
      obj.save_changes
    end

    def new_with_id(...)
      new(...).set_uuid
    end
  end
end
